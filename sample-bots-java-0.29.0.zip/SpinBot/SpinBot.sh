#!/bin/sh
java -cp ../lib/* SpinBot.java 
